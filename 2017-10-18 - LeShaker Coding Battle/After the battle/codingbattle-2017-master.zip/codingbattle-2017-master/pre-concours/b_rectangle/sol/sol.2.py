a,b=map(int,raw_input().split())
c=raw_input()
for _ in range(a):
    print c * b

