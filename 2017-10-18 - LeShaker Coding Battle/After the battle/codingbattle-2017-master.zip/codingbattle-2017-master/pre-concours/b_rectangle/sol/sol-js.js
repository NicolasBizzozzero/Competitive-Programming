[n, m] = readline().split(' ').map(Number);
c = readline();

for (var i = 0; i < n; i++) {
    print(c.repeat(m));
}

