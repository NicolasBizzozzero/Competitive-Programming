a,b=map(int,input().split())
c=input()
for _ in range(a):
    print(c * b)

