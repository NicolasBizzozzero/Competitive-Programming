print raw_input()[4:]
