#include <iostream>

using namespace std;

int main()
{
    string s;
    getline(cin, s);
    cout << s.substr(4) << endl;
}

