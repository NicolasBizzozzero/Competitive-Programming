print(input()[4:])
