<?php
echo substr(fgets(STDIN), 4);
