print(readline().substring(4))
