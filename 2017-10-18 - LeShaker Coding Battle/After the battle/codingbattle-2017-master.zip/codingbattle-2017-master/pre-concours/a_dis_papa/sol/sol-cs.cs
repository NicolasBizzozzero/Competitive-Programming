using System;

class Program
{
    static int Main()
    {
        String s = Console.ReadLine();
        Console.WriteLine(s.Substring(4));
        return 0;
    }
}

